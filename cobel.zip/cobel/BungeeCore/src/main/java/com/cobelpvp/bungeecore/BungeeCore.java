package com.cobelpvp.bungeecore;

import com.cobelpvp.bungeecore.commands.maintenanace.MaintenanceCommand;
import com.cobelpvp.bungeecore.listeners.MOTDListener;
import com.cobelpvp.bungeecore.listeners.MaintenanceListener;
import com.cobelpvp.bungeecore.utils.ConfigHelper;
import com.cobelpvp.bungeecore.commands.hub.HubCommand;
import com.cobelpvp.bungeecore.commands.motd.MOTDCommand;
import lombok.Getter;
import lombok.Setter;
import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.api.plugin.PluginManager;

@Getter @Setter
public class BungeeCore extends Plugin {

    @Getter
    private static BungeeCore plugin;

    // Maintenance
    @Getter public static Boolean serverInMaintenance;

    // Config's
    private ConfigHelper motd;
    private ConfigHelper maintenance;

    @Override
    public void onEnable() {
        plugin = this;

        /**
         * Plugin manager for register everything
         */
        PluginManager pluginManager = getProxy().getPluginManager();

        /**
         * Register the Configs
         */
        motd = new ConfigHelper(this, "motd.yml", true);
        maintenance = new ConfigHelper(this, "maintenance.yml", true);

        /**
         * Register the listeners
         */
        pluginManager.registerListener(this, new MaintenanceListener(this));
        pluginManager.registerListener(this, new MOTDListener(this));

        /**
         * Register the commands
         */
        pluginManager.registerCommand(this, new MaintenanceCommand(this));
        pluginManager.registerCommand(this, new MOTDCommand(this));
        pluginManager.registerCommand(this, new HubCommand());
    }

    @Override
    public void onDisable() {
        /**
         * Save the config
         */
        motd.save();
        maintenance.save();
    }
}
