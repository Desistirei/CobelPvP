package com.cobelpvp.atheneum.command;

public interface Data {
}
