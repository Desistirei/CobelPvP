package com.cobelpvp.atheneum.command.parameter.filter;

public class StrictFilter extends NormalFilter {
}
