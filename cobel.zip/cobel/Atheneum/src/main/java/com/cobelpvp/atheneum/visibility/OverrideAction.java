package com.cobelpvp.atheneum.visibility;

public enum OverrideAction
{
    SHOW,
    NEUTRAL;
}
