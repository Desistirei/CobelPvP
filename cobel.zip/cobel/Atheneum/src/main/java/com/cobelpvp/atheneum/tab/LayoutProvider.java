package com.cobelpvp.atheneum.tab;

import org.bukkit.entity.Player;

public interface LayoutProvider {
    TabLayout provide(final Player p0);
}
