package com.cobelpvp.atheneum.util.callback;

public interface ReturnableTypeCallback<T> {

    T call();

}
