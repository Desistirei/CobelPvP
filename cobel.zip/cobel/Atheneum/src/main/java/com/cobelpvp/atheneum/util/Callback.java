package com.cobelpvp.atheneum.util;

public interface Callback<T> {
    void callback(final T p0);
}
