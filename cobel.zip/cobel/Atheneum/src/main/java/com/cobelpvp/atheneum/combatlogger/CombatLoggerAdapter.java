package com.cobelpvp.atheneum.combatlogger;

import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class CombatLoggerAdapter {

    public void onEntityDamageByEntity(CombatLogger logger, EntityDamageByEntityEvent event) {
    }

    public void onEntityDeath(CombatLogger logger, EntityDeathEvent event) {
    }
}
