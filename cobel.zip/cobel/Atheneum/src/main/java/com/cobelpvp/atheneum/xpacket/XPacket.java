package com.cobelpvp.atheneum.xpacket;

public interface XPacket
{
    void onReceive();
}
