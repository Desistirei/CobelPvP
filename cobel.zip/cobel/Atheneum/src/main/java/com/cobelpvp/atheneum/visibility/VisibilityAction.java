package com.cobelpvp.atheneum.visibility;

public enum VisibilityAction
{
    HIDE,
    NEUTRAL;
}
