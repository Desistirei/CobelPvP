package com.cobelpvp.bond.packet.listener;

public interface PacketListener {
}
