package org.bukkit.entity;

/**
 * Represents a Monster.
 */
public interface Monster extends Creature {}
