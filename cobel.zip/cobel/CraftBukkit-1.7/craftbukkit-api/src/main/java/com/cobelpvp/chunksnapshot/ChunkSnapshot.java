package com.cobelpvp.chunksnapshot;

public interface ChunkSnapshot {

}
